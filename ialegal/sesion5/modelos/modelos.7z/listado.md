## I. Modelos Extrajudiciales (1-18)
### **Consumo y Servicios de Telefonía**
1. Reclamación por error de portabilidad en telefonía.
2. Reclamación por facturación indebida en telefonía.
3. Reclamación y desistimiento de curso online.
### **Transportes y Viajes**
4. Reclamación por vuelo cancelado.
5. Reclamación por vuelo retrasado.
### **Responsabilidad Civil y Daños**
6. Reclamación administrativa por aceite en calzada.
7. Reclamación administrativa por caída en la calle.
8. Reclamación extrajudicial por caída en tienda.
9. Reclamación patrimonial por caída de rama de árbol sobre coche.
10. Reclamación por filtraciones.
11. Reclamación por obras mal realizadas contra reformista.
12. Respuesta a burofax por rehúse de responsabilidad civil.
### **Administrativo y Arrendamientos**
13. Comunicación procedimiento contencioso a tercero interesado.
14. Escrito de personación en procedimiento administrativo.
15. Escrito de solicitud por silencio negativo.
16. Modelo comunicación no renovación contrato arrendamiento de vivienda.
17. Modelo de alegaciones contra multa de tráfico defecto de notificación.
18. Reclamación administrativa de aguas.

## II. Modelos Judiciales (19-148)
### **Inicio de Acciones: Demandas y Denuncias**
19. Demanda de filtraciones de agua contra vecino por daño emergente y lucro cesante.
20. Demanda de juicio verbal de desahucio por impago de rentas y reclamación.
21. Demanda ejecutiva dineraria.
22. Denuncia al juzgado por ocupación ilegal de plaza de garaje.
23. Denuncia por encriptación de datos.
24. Solicitud de monitorio con factura.
25. Solicitud de Medidas Cautelares.
26. Solicitud conciliación caída ascensor Comunidad Propietarios.
27. Solicitud de Habeas Corpus por motivos psiquiátricos.
28. Solicitud habeas corpus general detención ilegal.
### **Representación, Personación y Poderes**
29. Ampliación de plazo para acta apud acta.
30. Aportación apud acta.
31. Aportación apud acta previa audiencia previa.
32. Cambio de denominación social.
33. Comunicación de cambio de domicilio a efecto de notificaciones.
34. Comunicación de cambio de domicilio procesal.
35. Comunicación de cambio de letrado en proceso penal.
36. Comunicación de nombramiento de representante legal de persona jurídica.
37. Designación de abogado y procurador en diligencias previas.
38. Designación de letrado en el orden social.
39. Escrito de personación letrado administración pública nombramiento procurador sustituto.
40. Escrito de personación por interesado ex art 49 LJCA contencioso-administrativo.
41. Modelo de comunicación de cambio de letrado.
42. Modelo de escrito de personación en procedimiento civil.
43. Modelo de escrito para personación en apelación en audiencia provincial.
44. Personación del denunciado en delitos leves.
45. Personación en conciliación civil.
46. Personación en conciliación civil con oposición.
47. Personación en diligencias preliminares.
48. Personación en diligencias previas.
49. Personación en procedimiento social.
50. Personación rebelde en procedimiento civil.
51. Personación recurso casación unificación doctrina social TS.
52. Renuncia de letrado en el orden social.
### **Gestión de la Prueba y Documentación**
53. Aportación de documentación al proceso penal.
54. Aportación de informe pericial posterior.
55. Aportación de prueba documental anticipada.
56. Aportación de prueba documental anticipada por hecho nuevo.
57. Aportación de prueba documental anticipada posterior por nueva noticia.
58. Citación judicial de testigos.
59. Escrito de acreditación de emplazamiento a perito o testigo.
60. Escrito preparación prueba adelantada contencioso administrativo abreviado.
61. Modelo de escrito solicitando enumeración de documentos judicial.
62. Nota de minuta de prueba.
63. Solicitud de acceso a la grabación de declaración o juicio en instrucción.
64. Solicitud de acceso a la grabación de juicio oral ante juzgado de lo penal.
65. Solicitud de acceso y copia de expediente judicial para interesado.
66. Solicitud de copia íntegra de actuaciones penales.
67. Solicitud de preparación de prueba.
68. Solicitud diligencia reconocimiento fotográfico.
69. Copia testimoniada de actuaciones.
70. Copia testimoniada de demanda para solicitar acumulación.
### **Suspensiones y Gestión de Plazos**
71. Ampliación de plazo judicial.
72. Solicitud de suspensión de juicio por enfermedad del abogado ante juzgado de lo penal.
73. Solicitud de suspensión de juicio por enfermedad de abogado en delitos leves o rápidos.
74. Solicitud de suspensión de juicio por enfermedad de cliente.
75. Solicitud de suspensión de plazo por falta de documentación.
76. Solicitud de suspensión de vista y nuevo sealamiento por enfermedad del letrado.
77. Solicitud de suspensión por acuerdo.
78. Solicitud de suspensión por enfermedad.
79. Solicitud de traducción y suspensión de plazo.
80. Suspensión juicio social por emplazamiento tardío.
81. Suspensión juicio social por prejudicialidad recargo de prestaciones.
82. Suspensión y nuevo señalamiento por coincidencia del letrado (v1).
83. Suspensión y nuevo señalamiento por coincidencia del letrado (v2).
84. Suspensión y nuevo señalamiento por el perito.
85. Solicitud prórroga instrucción por acusación particular.
### **Desarrollo de Vistas y Trámite Procesal**
86. Averiguación domiciliaria citación judicial y testigos.
87. Averiguación domiciliaria y notificación edictal.
88. Datos para la vista telemática.
89. Escrito de conclusiones.
90. Escrito genérico de mero trámite.
91. Impulso procesal.
92. Instructa de juicio oral ordinario civil.
93. Instructa para juicio verbal.
94. Instructa vista procedimiento abreviado contencioso administrativo.
95. Modelo de instructa para la Audiencia Previa.
96. Modelo de escrito para solicitud de vista verbal.
97. Modelo de solicitud para no celebrar vista oral.
98. Solicitud de Comparecencia Telemática.
99. Solicitud de comparecencia telemática de perito.
100. Solicitud de impulso para señalar juicio oral.
101. Solicitud de subsanación de defectos en demanda.
### **Recursos, Alegaciones y Oposiciones**
102. Alegaciones del demandante sobre competencia territorial en consumo.
103. Ampliación de demanda.
104. Contestación a la Demanda de Oposición a Franquicia.
105. Escrito de defensa penal.
106. Escrito de no alegaciones a recurso de reposición Civil.
107. Oposición al desistimiento sin costas.
108. Oposición al incidente de nulidad de actuaciones.
109. Oposición al recurso de apelación sobre costas.
110. Oposición a medidas de ejecución provisional civil dineraria.
111. Oposición a monitorio inferior a 15.000€.
112. Oposición a monitorio superior a 15.000€.
113. Recurso de apelación.
114. Recurso de reforma y subsidiario de apelación.
115. Recurso de reposición frente a providencia por inadmisión de prueba.
116. Recurso de reposición sobre denegación de prueba.
117. Recurso de reposición sobre denegación de prueba pericial médica.
### **Incidentes de Finalización y Resoluciones**
118. Desistimiento consensuado.
119. Desistimiento solo contra codemandado por error.
120. Desistimiento unilateral.
121. Escrito de aclaración de resolución.
122. Escrito de aclaración de sentencia social.
123. Escrito de complemento de resolución.
124. Escrito de solicitud para publicación de convocatoria de subasta en el BOE.
125. Escrito solicitud archivo civil por concurso de acreedores.
126. Escrito solicitud archivo social por concurso de acreedores.
127. Escrito solicitud firmeza sentencia civil.
128. Homologación de acuerdo judicial.
129. Solicitud de acumulación de procedimientos ante el mismo tribunal.
130. Solicitud de acumulación de procedimientos ante tribunales distintos.
131. Solicitud de cancelación de antecedentes penales y policiales.
132. Solicitud de Sucesión Procesal por Fallecimiento.
133. Solicitud de sucesión procesal por transmisión del objeto litigioso.
### **Aspectos Económicos y Costas**
134. Aportación de CCC para pago de consignaciones.
135. Consignación de cantidad en condena.
136. Consignación de cantidad por allanamiento parcial.
137. Consignación de liquidación de intereses.
138. Escrito de impugnación por costas indebidas o excesivas.
139. Escrito instando costas.
140. Escrito instando costas e intereses.
141. Escrito proponiendo intereses.
142. Escrito solicitando averiguación patrimonial.
143. Jura de cuentas de procurador.
144. Justificante de pago de tasa.
145. Solicitud de Cuenta Corriente ante el juzgado.
146. Solicitud de devolución de efectos intervenidos.
147. Solicitud de devolución de ingreso indebido al fondo ingresos erróneos.
148. Terminación por satisfacción extraprocesal y carencia sobrevenida.

## III. Legislación de Referencia
* **Código Civil:** Marco sustantivo para obligaciones, contratos y responsabilidad.
* **Ley de Enjuiciamiento Civil (LEC):** Procedimientos civiles, monitorios y ejecución.
* **Código Penal y Ley de Enjuiciamiento Criminal (LECrim):** Delitos, denuncias e instrucción.
* **Ley de la Jurisdicción Contencioso-Administrativa (LJCA):** Relaciones con la Administración.
* **Estatuto General de la Abogacía:** Normas profesionales y de designación.